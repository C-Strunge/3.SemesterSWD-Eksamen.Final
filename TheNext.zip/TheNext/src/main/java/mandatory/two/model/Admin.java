package mandatory.two.model;

import javax.persistence.Entity;

/**
 * Created by Matthias Skou 30/11/2018
 */
//test
//dad   test
@Entity
public class Admin extends User {
}
